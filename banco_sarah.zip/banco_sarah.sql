-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 09/04/2025 às 19:04
-- Versão do servidor: 8.0.40
-- Versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_sarah`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `informacoespessoais_sarah`
--

CREATE TABLE `informacoespessoais_sarah` (
  `cpfid` int NOT NULL,
  `cpf` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `primeiro_nome` varchar(50) NOT NULL,
  `segundo_nome` varchar(50) NOT NULL,
  `endereco` varchar(100) NOT NULL,
  `cidade` varchar(40) NOT NULL,
  `estado` char(2) NOT NULL,
  `ddd` char(2) NOT NULL,
  `celular` varchar(9) NOT NULL,
  `email` varchar(255) NOT NULL,
  `senha` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `mes_nascimento` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `informacoespessoais_sarah`
--

INSERT INTO `informacoespessoais_sarah` (`cpfid`, `cpf`, `primeiro_nome`, `segundo_nome`, `endereco`, `cidade`, `estado`, `ddd`, `celular`, `email`, `senha`, `mes_nascimento`) VALUES
(3, '61143765109', 'Jhony', 'Peixoto', 'Paulista Albuerque,800', 'Rio de Janeiro', 'RJ', '21', '212121333', 'jhonypeixoto123@gmail.com', 'honypeixoto.123', '9'),
(4, '03129676830', 'Adriana', 'Meilres', 'Avenida Peixoto Lima ', 'Riozinho', 'RN', '22', '909098080', 'slaadriana@gmail.com', 'sladriana', '5'),
(6, '01371351813', 'Alana', 'Silva', 'Rua Adriana Silva 65', 'Sao Paulo', 'SP', '11', '909090909', 'adrianasilva@gmail.com', 'adrianasilva#', '5'),
(7, '54775642022', 'Fernada', 'Medrada', 'Avenida Rodrigues Tavares', 'São Bernado do Campos', 'SP', '11', '972573500', 'fernandamedrada@gmail.com', 'fernanda555', '7');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `informacoespessoais_sarah`
--
ALTER TABLE `informacoespessoais_sarah`
  ADD PRIMARY KEY (`cpfid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `informacoespessoais_sarah`
--
ALTER TABLE `informacoespessoais_sarah`
  MODIFY `cpfid` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
